const { Telegraf } = require('telegraf');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

const botToken = process.env.MANAGER_BOT_TOKEN || '8788726727:AAF4ziOO8N3gscxxOYfF531T1rhq0aDlzNE';
const adminId = process.env.CREATOR_ID || '8018436478';
const github = {
  token: process.env.GITHUB_TOKEN || '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',
  repoOwner: process.env.GITHUB_REPO_OWNER || 'apannns',
  repoName: process.env.GITHUB_REPO_NAME || 'database-neyx',
  filePath: process.env.GITHUB_TOKEN_FILE || 'tokens.json',
};

const bot = new Telegraf(botToken);
const roleFile = path.join(__dirname, '..', 'database', 'VaneDB.json');
if (!fs.existsSync(roleFile)) fs.writeFileSync(roleFile, JSON.stringify({ reseller: [], partners: [], moderators: [], owners: [], creators: [] }, null, 2));

function loadRoles() {
  return JSON.parse(fs.readFileSync(roleFile));
}
function saveRoles(data) {
  fs.writeFileSync(roleFile, JSON.stringify(data, null, 2));
}
function isCreator(id) {
  const roles = loadRoles();
  return roles.creators.map(String).includes(String(id)) || String(id) === String(adminId);
}
function getRole(id) {
  const roles = loadRoles();
  const uid = String(id);
  for (const role of ['creators','owners','moderators','partners','reseller']) {
    if ((roles[role] || []).map(String).includes(uid)) return role;
  }
  return null;
}
function hasPermission(id, permission) {
  const role = getRole(id);
  return !!role && (loadRoles().permissions?.[role] || []).includes(permission);
}
function isModerator(id) {
  return ['moderators','owners','creators'].includes(getRole(id)) || isCreator(id);
}
function isOwner(id) {
  return ['owners','creators'].includes(getRole(id)) || isCreator(id);
}
function isReseller(id) {
  return ['reseller','partners','moderators','owners','creators'].includes(getRole(id)) || isCreator(id);
}
function requireCreator(id) {
  if (!isCreator(id)) throw new Error('Akses ditolak. Hanya creator yang dapat mengelola role.');
}
function addRole(type, id) {
  requireCreator(adminId); // function itself is guarded by command caller below
  const roles = loadRoles();
  if (!roles[type]) roles[type] = [];
  if (!roles[type].map(String).includes(String(id))) {
    roles[type].push(String(id));
    saveRoles(roles);
  }
}
function removeRole(type, id) {
  requireCreator(adminId);
  const roles = loadRoles();
  roles[type] = (roles[type] || []).filter(i => String(i) !== String(id));
  saveRoles(roles);
}

const baseUrl = `https://api.github.com/repos/${github.repoOwner}/${github.repoName}/contents/${github.filePath}`;
const headers = {
  Authorization: `token ${github.token}`,
  'Accept': 'application/vnd.github.v3+json'
};

async function getFileContent() {
  try {
    const { data } = await axios.get(baseUrl, { headers });
    let content = Buffer.from(data.content, 'base64').toString('utf8');
    let parsed = JSON.parse(content);
    return { content: parsed.tokens || [], sha: data.sha };
  } catch (error) {
    if (error.response && error.response.status === 404) {
      return { content: [], sha: null };
    }
    throw new Error("Gagal mengambil data dari GitHub.");
  }
}

async function updateFileContent(newContent, sha) {
  const payload = {
    message: "Update tokens",
    content: Buffer.from(JSON.stringify({ tokens: newContent }, null, 2)).toString('base64'),
    sha: sha || undefined,
  };
  await axios.put(baseUrl, payload, { headers });
}

async function addToken(token) {
  const { content, sha } = await getFileContent();
  if (content.includes(token)) throw new Error("Token sudah ada yatim.");
  content.push(token);
  await updateFileContent(content, sha);
}
async function deleteToken(token) {
  const { content, sha } = await getFileContent();
  const newContent = content.filter(t => t !== token);
  await updateFileContent(newContent, sha);
}
async function getTokens() {
  const { content } = await getFileContent();
  return content;
}

// Start Command
bot.start(async (ctx) => {
  const chatId = ctx.chat.id;
  const ownerLink  = 'http://t.me/ungcikidaw';
  const developLink  = 'http://t.me/ungcikidaw';
  const asistenLink  = 'http://t.me/MelvinquOfficial';
  const channelLink = 'https://t.me/ungcikidaww';

  const text = `
<blockquote>Script Data Base X-Over</blockquote>
Developer : @ungcikidaw
Version : 4.0 
Script : X-Over 

<blockquote><b>ʀᴇsᴇʟʟᴇʀ ᴍᴇɴᴜ</b></blockquote>
/addtoken
/deltoken
/listtoken
<blockquote><b>ᴘᴀʀᴛɴᴇʀ ᴍᴇɴᴜ</b></blockquote>
/addres
/delres
<blockquote><b>ᴏᴡɴᴇʀ ᴍᴇɴᴜ</b></blockquote>
/addpt
/delpt
<blockquote><b>ᴀᴅᴍɪɴ ᴍᴇɴᴜ</b></blockquote>
/addown
/delown
`;

  await ctx.telegram.sendPhoto(chatId, "https://files.catbox.moe/e2wdir.jpg", {
    caption: text,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "Creator", url: ownerLink },
          { text: "Developer2", url: developLink },
          ],
          [
          { text: "Asisten", url: asistenLink },
          ],
          [
          { text: "Information", url: channelLink }
        ]
      ]
    }
  });
});

// Command Handlers
bot.command('addtoken', async (ctx) => {
  if (!isReseller(ctx.from.id)) return ctx.reply("❌ Akses ditolak.");
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /addtoken [token]");
  try {
    await addToken(args[1]);
    ctx.reply("✅ Token ditambahkan.");
  } catch (err) {
    ctx.reply("⚠️ " + err.message);
  }
});
bot.command('deltoken', async (ctx) => {
  if (!isReseller(ctx.from.id)) return ctx.reply("❌ Akses ditolak.");
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /deltoken [token]");
  try {
    await deleteToken(args[1]);
    ctx.reply("✅ Token dihapus.");
  } catch (err) {
    ctx.reply("⚠️ Gagal menghapus token.");
  }
});
bot.command('listtoken', async (ctx) => {
  if (!isModerator(ctx.from.id)) return ctx.reply("❌ Akses ditolak.");
  try {
    const tokens = await getTokens();
    if (tokens.length === 0) return ctx.reply("Tidak ada token.");
    const msg = tokens.map((t, i) => {
      const masked = t.length > 10 ? `${t.slice(0, 5)}*****${t.slice(-5)}` : `${t.slice(0, 2)}*****${t.slice(-2)}`;
      return `${i + 1}. \`${masked}\``;
    }).join('\n');
    ctx.reply(`Daftar Token (disamarkan):\n${msg}`, { parse_mode: "Markdown" });
  } catch {
    ctx.reply("⚠️ Gagal mengambil token.");
  }
});
bot.command('addres', async (ctx) => {
  try { requireCreator(ctx.from.id); } catch (e) { return ctx.reply('❌ ' + e.message); }
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /addres [user_id]");
  addRole('reseller', args[1]);
  ctx.reply("✅ Reseller ditambahkan.");
});
bot.command('delres', async (ctx) => {
  try { requireCreator(ctx.from.id); } catch (e) { return ctx.reply('❌ ' + e.message); }
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /delres [user_id]");
  removeRole('reseller', args[1]);
  ctx.reply("✅ Reseller dihapus.");
});
bot.command('addpt', async (ctx) => {
  try { requireCreator(ctx.from.id); } catch (e) { return ctx.reply('❌ ' + e.message); }
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /addpt [user_id]");
  addRole('partners', args[1]);
  ctx.reply("✅ Partner ditambahkan.");
});
bot.command('delpt', async (ctx) => {
  try { requireCreator(ctx.from.id); } catch (e) { return ctx.reply('❌ ' + e.message); }
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /delpt [user_id]");
  removeRole('partners', args[1]);
  ctx.reply("✅ Partner dihapus.");
});
bot.command('addown', async (ctx) => {
  try { requireCreator(ctx.from.id); } catch (e) { return ctx.reply('❌ ' + e.message); }
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /addown [user_id]");
  addRole('owners', args[1]);
  ctx.reply("✅ Owner ditambahkan.");
});
bot.command('delown', async (ctx) => {
  try { requireCreator(ctx.from.id); } catch (e) { return ctx.reply('❌ ' + e.message); }
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /delown [user_id]");
  removeRole('owners', args[1]);
  ctx.reply("✅ Owner dihapus.");
});
bot.command('addceo', async (ctx) => {
  try { requireCreator(ctx.from.id); } catch (e) { return ctx.reply('❌ ' + e.message); }
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /addceo [user_id]");
  addRole('creators', args[1]);
  ctx.reply("✅ Creator ditambahkan.");
});
bot.command('delceo', async (ctx) => {
  try { requireCreator(ctx.from.id); } catch (e) { return ctx.reply('❌ ' + e.message); }
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /delceo [user_id]");
  removeRole('creators', args[1]);
  ctx.reply("✅ Ceo dihapus.");
});
bot.command('addmodz', async (ctx) => {
  try { requireCreator(ctx.from.id); } catch (e) { return ctx.reply('❌ ' + e.message); }
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /addmodz [user_id]");
  addRole('moderators', args[1]);
  ctx.reply("✅ Moderator ditambahkan.");
});
bot.command('delmodz', async (ctx) => {
  try { requireCreator(ctx.from.id); } catch (e) { return ctx.reply('❌ ' + e.message); }
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /delmodz [user_id]");
  removeRole('moderators', args[1]);
  ctx.reply("✅ Modz dihapus.");
});

bot.launch();
console.log("BOT ADDTOKEN VANEGETA ON");