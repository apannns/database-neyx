# VaneSystem

Struktur:
- `manager/` = SC Manager: addrole/delrole + addtoken/deltoken/listtoken.
- `runner/` = SC LGI: hanya menjalankan fungsi LGI; tidak memiliki command addrole.
- `database/VaneDB.json` = database role bersama.

Urutan role:
`reseller -> partners -> moderators -> owners -> creators`

Hanya `creators` yang dapat mengelola role.

## Menjalankan
Manager:
`cd manager && npm install && npm start`

Runner:
`cd runner && npm install && npm start`

Environment:
- Manager: `MANAGER_BOT_TOKEN`, `CREATOR_ID`, `GITHUB_TOKEN`, `GITHUB_REPO_OWNER`, `GITHUB_REPO_NAME`, `GITHUB_TOKEN_FILE`
- Runner: `LGI_BOT_TOKEN`, `CREATOR_ID`

Credential dari file upload asli tidak disalin ke paket hasil; gunakan environment variable.
